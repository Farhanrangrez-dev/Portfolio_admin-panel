import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import Admin from './Routes/Admin';
import Login from "./features/auth/LoginPage";
import Signup from "./features/auth/SignupPage";

function App() {

  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />
      <Router>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/signup" element={<Signup/>} />
           
          {/* <Route path="/resetPassword" element={<ResetPassword/>} /> */}

          {/* Admin Routes */}
          <Route path='/admin/*' element={<Admin />} />
   
        </Routes>
      </Router>
      <ToastContainer position="top-right" autoClose={3000} />
    </>
  );
}

export default App;