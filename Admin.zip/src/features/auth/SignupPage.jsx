import React from 'react'

function SignupPage() {
  return (
    <>
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center">
                <h1 className="text-2xl font-bold text-gray-800" style={{ fontFamily: 'Pacifico, serif' }}>Travnet.io</h1>
              </div>
              <div className="hidden md:block">
                <p className="text-sm text-gray-500">Connect. Transact. Grow Your Travel Business.</p>
              </div>
              <div>
                <a className="text-orange-600 hover:text-orange-800 font-medium transition-colors duration-200" href="/preview/ad6b4238-e269-4a8a-8732-b33b0c128bc4/2699197/auth/login" data-discover="true">Log in</a>
              </div>
            </div>
          </div>
        </header>
        <div className="flex">
          <div className="hidden lg:flex lg:w-2/5 bg-gradient-to-br from-orange-50 to-red-100 relative overflow-hidden">
            <div className="flex flex-col justify-center w-full px-12 py-16 relative z-10">
              <div className="max-w-md">
                <img
                  alt="Travel Business Network"
                  className="w-full h-48 object-cover object-center rounded-2xl mb-8 shadow-lg"
                  src="https://readdy.ai/api/search-image?query=Professional%20travel%20business%20network%20illustration%20with%20subtle%20elements%2C%20airplane%20routes%20connecting%20global%20destinations%2C%20modern%20clean%20design%20with%20warm%20orange%20and%20red%20accents%2C%20business-focused%20travel%20technology%20theme%2C%20minimalist%20professional%20style&width=500&height=300&seq=travel-signup-hero-professional&orientation=landscape"
                />
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <i className="ri-shield-check-line text-orange-600 text-lg"></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800 text-lg">Escrow-protected transactions</h3>
                      <p className="text-sm text-gray-600">Secure payments with built-in buyer protection for all bookings</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <i className="ri-robot-line text-orange-600 text-lg"></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800 text-lg">AI itinerary & pricing tools</h3>
                      <p className="text-sm text-gray-600">Smart automation for faster quote generation and optimization</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <i className="ri-global-line text-orange-600 text-lg"></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800 text-lg">Global B2B marketplace</h3>
                      <p className="text-sm text-gray-600">Connect with verified travel partners across 150+ countries</p>
                    </div>
                  </div>
                </div>
                <div className="mt-8">
                  <button className="text-sm text-orange-600 hover:text-orange-800 font-medium transition-colors duration-200 flex items-center cursor-pointer">
                    See plan feature comparison<i className="ri-arrow-right-line ml-1"></i>
                  </button>
                </div>
              </div>
            </div>
            <div className="absolute top-20 left-20 w-24 h-24 bg-orange-200 rounded-full opacity-20"></div>
            <div className="absolute bottom-32 right-16 w-32 h-32 bg-red-200 rounded-full opacity-25"></div>
          </div>
          <div className="w-full lg:w-3/5 flex flex-col justify-center px-8 lg:px-12 py-16">
            <div className="max-w-2xl mx-auto w-full">
              <div className="mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-2">Create your Travnet.io account</h2>
                <p className="text-gray-600"><span className="text-green-600 font-medium">14-day free trial</span> • No credit card required to start</p>
              </div>
              <form className="space-y-8">
                <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center"><i className="ri-user-line text-orange-600 mr-2"></i>Account Owner</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                      <input required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200 text-sm" placeholder="Enter first name" type="text" value="" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                      <input required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200 text-sm" placeholder="Enter last name" type="text" value="" />
                    </div>
                  </div>
                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Work Email</label>
                    <input required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200 text-sm" placeholder="Enter work email" type="email" value="" />
                    <p className="text-xs text-gray-500 mt-1">We'll send a verification link.</p>
                  </div>
                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Mobile Number</label>
                    <div className="flex space-x-3">
                      <select className="px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm pr-8">
                        <option value="+1">+1 (US/CA)</option>
                        <option value="+44">+44 (UK)</option>
                        <option value="+91">+91 (IN)</option>
                        <option value="+61">+61 (AU)</option>
                        <option value="+49">+49 (DE)</option>
                        <option value="+33">+33 (FR)</option>
                        <option value="+65">+65 (SG)</option>
                        <option value="+971">+971 (AE)</option>
                        <option value="+81">+81 (JP)</option>
                        <option value="+55">+55 (BR)</option>
                      </select>
                      <input required className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200 text-sm" placeholder="Enter mobile number" type="tel" value="" />
                    </div>
                  </div>
                </div>
                <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center"><i className="ri-building-line text-orange-600 mr-2"></i>Agency / Company</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Agency / Company Name</label>
                      <input required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200 text-sm" placeholder="Enter agency/company name" type="text" value="" />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Country</label>
                        <select required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm pr-8">
                          <option value="">Select country</option>
                          <option value="United States">United States</option>
                          <option value="United Kingdom">United Kingdom</option>
                          <option value="Canada">Canada</option>
                          <option value="Australia">Australia</option>
                          <option value="India">India</option>
                          <option value="Germany">Germany</option>
                          <option value="France">France</option>
                          <option value="Singapore">Singapore</option>
                          <option value="UAE">UAE</option>
                          <option value="Japan">Japan</option>
                          <option value="Brazil">Brazil</option>
                          <option value="Mexico">Mexico</option>
                          <option value="South Africa">South Africa</option>
                          <option value="New Zealand">New Zealand</option>
                          <option value="Thailand">Thailand</option>
                          <option value="Malaysia">Malaysia</option>
                          <option value="Philippines">Philippines</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Primary Currency</label>
                        <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm pr-8">
                          <option value="USD">USD</option>
                          <option value="EUR">EUR</option>
                          <option value="GBP">GBP</option>
                          <option value="CAD">CAD</option>
                          <option value="AUD">AUD</option>
                          <option value="INR">INR</option>
                          <option value="SGD">SGD</option>
                          <option value="AED">AED</option>
                          <option value="JPY">JPY</option>
                          <option value="BRL">BRL</option>
                          <option value="MXN">MXN</option>
                          <option value="ZAR">ZAR</option>
                          <option value="NZD">NZD</option>
                          <option value="THB">THB</option>
                          <option value="MYR">MYR</option>
                          <option value="PHP">PHP</option>
                        </select>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Business Type</label>
                        <select required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm pr-8">
                          <option value="">Select business type</option>
                          <option value="Travel Agency">Travel Agency</option>
                          <option value="DMC">DMC</option>
                          <option value="OTA">OTA</option>
                          <option value="Freelancer">Freelancer</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">GST/VAT/Tax ID <span className="text-gray-400">(Optional)</span></label>
                        <input className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200 text-sm" placeholder="Enter tax ID" type="text" value="" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center"><i className="ri-price-tag-3-line text-orange-600 mr-2"></i>Plan Selection</h3>
                    <div className="flex items-center space-x-3">
                      <span className="text-sm text-gray-900 font-medium">Monthly</span>
                      <button type="button" className="relative inline-flex h-6 w-11 items-center rounded-full transition-colors bg-gray-200">
                        <span className="inline-block h-4 w-4 transform rounded-full bg-white transition-transform translate-x-1"></span>
                      </button>
                      <span className="text-sm text-gray-500">Annually <span className="text-green-600 text-xs">(save 2400%)</span></span>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="relative border-2 rounded-lg p-5 cursor-pointer transition-all duration-200 border-gray-200 hover:border-orange-300 hover:shadow-md">
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-3">
                          <input className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 mr-2" type="radio" value="base" name="plan" />
                          <h4 className="text-xl font-bold text-gray-900">Base</h4>
                        </div>
                        <div className="mb-4">
                          <span className="text-3xl font-bold text-gray-900">$49</span>
                          <span className="text-gray-500 text-sm block">/month</span>
                        </div>
                        <div className="text-sm text-orange-600 font-semibold mb-4 bg-orange-100 py-1 px-2 rounded">1 Partner</div>
                        <ul className="text-sm text-gray-600 space-y-2 text-left">
                          <li className="flex items-start"><i className="ri-check-line text-green-500 mr-2 mt-0.5 flex-shrink-0"></i>Basic booking management</li>
                          <li className="flex items-start"><i className="ri-check-line text-green-500 mr-2 mt-0.5 flex-shrink-0"></i>Email support</li>
                          <li className="flex items-start"><i className="ri-check-line text-green-500 mr-2 mt-0.5 flex-shrink-0"></i>Standard reporting</li>
                        </ul>
                      </div>
                    </div>
                    <div className="relative border-2 rounded-lg p-5 cursor-pointer transition-all duration-200 border-orange-500 bg-orange-50 shadow-lg">
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                        <span className="bg-orange-600 text-white text-xs px-3 py-1 rounded-full font-medium shadow-sm">Most Popular</span>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-3">
                          <input className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 mr-2" type="radio" value="premium" defaultChecked name="plan" />
                          <h4 className="text-xl font-bold text-gray-900">Premium</h4>
                        </div>
                        <div className="mb-4">
                          <span className="text-3xl font-bold text-gray-900">$149</span>
                          <span className="text-gray-500 text-sm block">/month</span>
                        </div>
                        <div className="text-sm text-orange-600 font-semibold mb-4 bg-orange-100 py-1 px-2 rounded">5 Partners</div>
                        <ul className="text-sm text-gray-600 space-y-2 text-left">
                          <li className="flex items-start"><i className="ri-check-line text-green-500 mr-2 mt-0.5 flex-shrink-0"></i>AI itinerary tools</li>
                          <li className="flex items-start"><i className="ri-check-line text-green-500 mr-2 mt-0.5 flex-shrink-0"></i>Priority support</li>
                          <li className="flex items-start"><i className="ri-check-line text-green-500 mr-2 mt-0.5 flex-shrink-0"></i>Advanced analytics</li>
                        </ul>
                      </div>
                    </div>
                    <div className="relative border-2 rounded-lg p-5 cursor-pointer transition-all duration-200 border-gray-200 hover:border-orange-300 hover:shadow-md">
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-3">
                          <input className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 mr-2" type="radio" value="platinum" name="plan" />
                          <h4 className="text-xl font-bold text-gray-900">Platinum</h4>
                        </div>
                        <div className="mb-4">
                          <span className="text-3xl font-bold text-gray-900">$299</span>
                          <span className="text-gray-500 text-sm block">/month</span>
                        </div>
                        <div className="text-sm text-orange-600 font-semibold mb-4 bg-orange-100 py-1 px-2 rounded">10 Partners</div>
                        <ul className="text-sm text-gray-600 space-y-2 text-left">
                          <li className="flex items-start"><i className="ri-check-line text-green-500 mr-2 mt-0.5 flex-shrink-0"></i>White-label solution</li>
                          <li className="flex items-start"><i className="ri-check-line text-green-500 mr-2 mt-0.5 flex-shrink-0"></i>24/7 phone support</li>
                          <li className="flex items-start"><i className="ri-check-line text-green-500 mr-2 mt-0.5 flex-shrink-0"></i>Custom integrations</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <button type="submit" className="w-full bg-orange-600 text-white py-4 px-6 rounded-lg font-medium hover:bg-orange-700 focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed text-lg whitespace-nowrap shadow-lg">Start Free Trial - $149/month after 14 days</button>
                <p className="text-xs text-gray-500 text-center">By creating an account, you agree to our <a className="text-orange-600 hover:text-orange-800" href="/preview/ad6b4238-e269-4a8a-8732-b33b0c128bc4/2699197/terms" data-discover="true">Terms of Service</a> and <a className="text-orange-600 hover:text-orange-800" href="/preview/ad6b4238-e269-4a8a-8732-b33b0c128bc4/2699197/privacy" data-discover="true">Privacy Policy</a></p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default SignupPage
