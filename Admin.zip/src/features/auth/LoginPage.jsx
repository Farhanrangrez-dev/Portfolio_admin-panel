import React from 'react'
import { Link, useNavigate } from 'react-router-dom'

function LoginPage() {
  const navigate =useNavigate()
  const handleLogin=(e)=>{
    e.preventDefault()
    navigate("/admin/dashboard")
  }
  
  return (
    <>
<div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
  <div className="w-full max-w-md">
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-[#facc15] rounded-xl flex items-center justify-center mx-auto mb-4">
          <i className="ri-shield-user-line text-3xl text-black" />
        </div>
        <h1 className="text-2xl font-bold text-black">Admin Login</h1>
        <p className="text-gray-500 mt-2">Portfolio Management Panel</p>
      </div>
      <form className="space-y-6" onSubmit={handleLogin}>
        <div>
          <label className="block text-sm font-medium text-black mb-2">
            Email Address
          </label>
          <div className="relative">
            <i className="ri-mail-line absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#facc15] focus:border-transparent transition-all"
              placeholder="admin@portfolio.com"
              required=""
              type="email"
              defaultValue=""
            />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-black mb-2">
            Password
          </label>
          <div className="relative">
            <i className="ri-lock-line absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#facc15] focus:border-transparent transition-all"
              placeholder="••••••••"
              required=""
              type="password"
              defaultValue=""
            />
          </div>
        </div>
        <button
          type="submit"
          className="w-full bg-[#facc15] text-black font-semibold py-3 rounded-lg hover:bg-[#eab308] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <span>Sign In</span>
          <i className="ri-arrow-right-line" />
        </button>
      </form>
      <div className="mt-6 p-4 bg-gray-50 rounded-lg">
        <p className="text-xs text-gray-500 text-center">
          <span className="font-medium">Demo:</span> admin@portfolio.com /
          admin123
        </p>
      </div>
    </div>
  </div>
</div>

    </>
  )
}

export default LoginPage
