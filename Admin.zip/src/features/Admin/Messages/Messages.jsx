import React from 'react'

function Messages() {
  return (
 
  <div className="animate-fadeIn">
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-black">Messages</h1>
          <p className="text-gray-500 mt-1">No new messages</p>
        </div>
        <div className="flex items-center gap-2 bg-gray-100 rounded-lg p-1">
          <button className="px-4 py-2 rounded-md font-medium transition-colors bg-white shadow-sm text-black">
            All
          </button>
          <button className="px-4 py-2 rounded-md font-medium transition-colors text-gray-500 hover:text-black">
            Unread{" "}
          </button>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <div className="p-4 rounded-xl cursor-pointer transition-all bg-white hover:bg-gray-50 border-transparent">
            <div className="flex items-start justify-between mb-2">
              <h3 className="font-semibold text-black">John Smith</h3>
              <span className="text-xs text-gray-400">25/02/2026</span>
            </div>
            <p className="text-sm line-clamp-2 text-gray-500">
              Hi there! I came across your portfolio and was really impressed
              with your work. I would love to discuss a potential project
              collaboration. Please let me know if you are available for a quick
              chat.
            </p>
          </div>
          <div className="p-4 rounded-xl cursor-pointer transition-all bg-white hover:bg-gray-50 border-transparent">
            <div className="flex items-start justify-between mb-2">
              <h3 className="font-semibold text-black">Sarah Johnson</h3>
              <span className="text-xs text-gray-400">24/02/2026</span>
            </div>
            <p className="text-sm line-clamp-2 text-gray-500">
              Hello! I am reaching out from TechCorp regarding a frontend
              developer position. Your React projects look amazing and we think
              you would be a great fit. Would you be interested in learning
              more?
            </p>
          </div>
          <div className="p-4 rounded-xl cursor-pointer transition-all bg-white hover:bg-gray-50 border-transparent">
            <div className="flex items-start justify-between mb-2">
              <h3 className="font-semibold text-black">Mike Chen</h3>
              <span className="text-xs text-gray-400">23/02/2026</span>
            </div>
            <p className="text-sm line-clamp-2 text-gray-500">
              Hey! Love your portfolio design. Quick question - what tech stack
              did you use for your e-commerce project? I am building something
              similar and would appreciate any insights.
            </p>
          </div>
          <div className="text-center py-12 bg-white rounded-xl">
  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
    <i className="ri-mail-line text-2xl text-gray-400" />
  </div>
  <p className="text-gray-500">No messages</p>
</div>

        </div>
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl p-12 text-center">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-mail-open-line text-3xl text-gray-400" />
            </div>
            <h3 className="text-xl font-bold text-black mb-2">
              Select a message
            </h3>
            <p className="text-gray-500">
              Click on a message from the list to view its contents
            </p>
          </div>
        </div>
      </div>
    </div>


    </div>
  )
}

export default Messages
