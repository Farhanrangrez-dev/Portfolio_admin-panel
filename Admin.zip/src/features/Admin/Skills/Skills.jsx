
















import React, { useState } from 'react'

function Skills() {

  const [isOpen, setIsOpen] = useState(false)
  const [proficiency, setProficiency] = useState(50)

  return (
    <div>
      <div className="space-y-6 pb-5">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-black">Skills</h1>
            <p className="text-gray-500 mt-1">
              Manage your technical skills and expertise
            </p>
          </div>
          <button
            onClick={() => setIsOpen(true)}
            className="bg-[#facc15] text-black px-5 py-2.5 rounded-lg font-semibold hover:bg-[#eab308] transition-colors flex items-center gap-2 w-fit"
          >
            <i className="ri-add-line" />
            <span>Add Skill</span>
          </button>
        </div>

        {/* ===== YOUR COMPLETE EXISTING SECTIONS SAME AS BEFORE ===== */}
             <div className="space-y-8">
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-[#facc15] rounded-lg flex items-center justify-center">
              <i className="ri-stack-line text-black" />
            </div>
            <h2 className="text-xl font-bold text-black">Frontend</h2>
            <span className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600">
              5
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 border border-gray-100 rounded-xl hover:border-[#facc15]/30 hover:shadow-sm transition-all group">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-black">React.js</h3>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-1.5 text-gray-400 hover:text-[#facc15] transition-colors">
                    <i className="ri-edit-line" />
                  </button>
                  <button className="p-1.5 text-gray-400 hover:text-red-500 transition-colors">
                    <i className="ri-delete-bin-line" />
                  </button>
                </div>
              </div>
              <div className="relative">
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#facc15] rounded-full transition-all duration-500"
                    style={{ width: "90%" }}
                  />
                </div>
                <span className="absolute right-0 -top-6 text-sm font-medium text-gray-600">
                  90%
                </span>
              </div>
            </div>
            <div className="p-4 border border-gray-100 rounded-xl hover:border-[#facc15]/30 hover:shadow-sm transition-all group">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-black">TypeScript</h3>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-1.5 text-gray-400 hover:text-[#facc15] transition-colors">
                    <i className="ri-edit-line" />
                  </button>
                  <button className="p-1.5 text-gray-400 hover:text-red-500 transition-colors">
                    <i className="ri-delete-bin-line" />
                  </button>
                </div>
              </div>
              <div className="relative">
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#facc15] rounded-full transition-all duration-500"
                    style={{ width: "85%" }}
                  />
                </div>
                <span className="absolute right-0 -top-6 text-sm font-medium text-gray-600">
                  85%
                </span>
              </div>
            </div>
            <div className="p-4 border border-gray-100 rounded-xl hover:border-[#facc15]/30 hover:shadow-sm transition-all group">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-black">HTML/CSS</h3>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-1.5 text-gray-400 hover:text-[#facc15] transition-colors">
                    <i className="ri-edit-line" />
                  </button>
                  <button className="p-1.5 text-gray-400 hover:text-red-500 transition-colors">
                    <i className="ri-delete-bin-line" />
                  </button>
                </div>
              </div>
              <div className="relative">
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#facc15] rounded-full transition-all duration-500"
                    style={{ width: "92%" }}
                  />
                </div>
                <span className="absolute right-0 -top-6 text-sm font-medium text-gray-600">
                  92%
                </span>
              </div>
            </div>
            <div className="p-4 border border-gray-100 rounded-xl hover:border-[#facc15]/30 hover:shadow-sm transition-all group">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-black">JavaScript</h3>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-1.5 text-gray-400 hover:text-[#facc15] transition-colors">
                    <i className="ri-edit-line" />
                  </button>
                  <button className="p-1.5 text-gray-400 hover:text-red-500 transition-colors">
                    <i className="ri-delete-bin-line" />
                  </button>
                </div>
              </div>
              <div className="relative">
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#facc15] rounded-full transition-all duration-500"
                    style={{ width: "92%" }}
                  />
                </div>
                <span className="absolute right-0 -top-6 text-sm font-medium text-gray-600">
                  92%
                </span>
              </div>
            </div>
            <div className="p-4 border border-gray-100 rounded-xl hover:border-[#facc15]/30 hover:shadow-sm transition-all group">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-black">Shopfiy app</h3>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-1.5 text-gray-400 hover:text-[#facc15] transition-colors">
                    <i className="ri-edit-line" />
                  </button>
                  <button className="p-1.5 text-gray-400 hover:text-red-500 transition-colors">
                    <i className="ri-delete-bin-line" />
                  </button>
                </div>
              </div>
              <div className="relative">
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#facc15] rounded-full transition-all duration-500"
                    style={{ width: "30%" }}
                  />
                </div>
                <span className="absolute right-0 -top-6 text-sm font-medium text-gray-600">
                  30%
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-[#facc15] rounded-lg flex items-center justify-center">
              <i className="ri-stack-line text-black" />
            </div>
            <h2 className="text-xl font-bold text-black">Backend</h2>
            <span className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600">
              1
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 border border-gray-100 rounded-xl hover:border-[#facc15]/30 hover:shadow-sm transition-all group">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-black">Node.js</h3>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-1.5 text-gray-400 hover:text-[#facc15] transition-colors">
                    <i className="ri-edit-line" />
                  </button>
                  <button className="p-1.5 text-gray-400 hover:text-red-500 transition-colors">
                    <i className="ri-delete-bin-line" />
                  </button>
                </div>
              </div>
              <div className="relative">
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#facc15] rounded-full transition-all duration-500"
                    style={{ width: "80%" }}
                  />
                </div>
                <span className="absolute right-0 -top-6 text-sm font-medium text-gray-600">
                  80%
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-[#facc15] rounded-lg flex items-center justify-center">
              <i className="ri-stack-line text-black" />
            </div>
            <h2 className="text-xl font-bold text-black">Database</h2>
            <span className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600">
              1
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 border border-gray-100 rounded-xl hover:border-[#facc15]/30 hover:shadow-sm transition-all group">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-black">MongoDB</h3>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-1.5 text-gray-400 hover:text-[#facc15] transition-colors">
                    <i className="ri-edit-line" />
                  </button>
                  <button className="p-1.5 text-gray-400 hover:text-red-500 transition-colors">
                    <i className="ri-delete-bin-line" />
                  </button>
                </div>
              </div>
              <div className="relative">
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#facc15] rounded-full transition-all duration-500"
                    style={{ width: "75%" }}
                  />
                </div>
                <span className="absolute right-0 -top-6 text-sm font-medium text-gray-600">
                  75%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
        {/* (Frontend, Backend, Database sections — bilkul same rakhein) */}

        <button
          onClick={() => setIsOpen(true)}
          className="w-full p-8 border-2 border-dashed border-gray-300 rounded-xl hover:border-[#facc15] hover:bg-[#facc15]/5 transition-all group"
        >
          <div className="flex flex-col items-center gap-3">
            <div className="w-14 h-14 bg-gray-100 rounded-full flex items-center justify-center group-hover:bg-[#facc15] transition-colors">
              <i className="ri-add-line text-2xl text-gray-400 group-hover:text-black" />
            </div>
            <span className="font-medium text-gray-500 group-hover:text-black">
              Add New Skill
            </span>
          </div>
        </button>
      </div>

      {/* ================= MODAL ================= */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md">

            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-black">
                  Add New Skill
                </h2>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <i className="ri-close-line text-2xl"></i>
                </button>
              </div>
            </div>

            <form className="p-6 space-y-6">

              <div>
                <label className="block text-sm font-medium text-black mb-2">
                  Skill Name *
                </label>
                <input
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#facc15] focus:border-transparent"
                  placeholder="e.g., React.js"
                  required
                  type="text"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-black mb-2">
                  Category *
                </label>
                <select
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#facc15] focus:border-transparent"
                  required
                >
                  <option value="Frontend">Frontend</option>
                  <option value="Backend">Backend</option>
                  <option value="Database">Database</option>
                  <option value="Design">Design</option>
                  <option value="Tools">Tools</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              {/* ✅ FIXED PROFICIENCY SECTION */}
              <div>
                <label className="block text-sm font-medium text-black mb-2">
                  Proficiency ({proficiency}%)
                </label>

                <input
                  min="0"
                  max="100"
                  value={proficiency}
                  onChange={(e) => setProficiency(e.target.value)}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#facc15]"
                  type="range"
                />

                <div className="flex justify-between text-sm text-gray-500 mt-1">
                  <span>Beginner</span>
                  <span>Expert</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="px-6 py-3 border border-gray-200 rounded-lg font-medium hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-6 py-3 bg-[#facc15] text-black rounded-lg font-semibold hover:bg-[#eab308] transition-colors"
                >
                  Add Skill
                </button>
              </div>

            </form>
          </div>
        </div>
      )}
    </div>
  )
}

export default Skills