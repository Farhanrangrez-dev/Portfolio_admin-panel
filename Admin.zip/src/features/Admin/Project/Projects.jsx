import React, { useState } from 'react'

function Projects() {

  const [isOpen, setIsOpen] = useState(false)

  return (
    <div>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-black">Projects</h1>
            <p className="text-gray-500 mt-1">Manage your portfolio projects</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsOpen(true)}
              className="bg-[#facc15] text-black px-5 py-2.5 rounded-lg font-semibold hover:bg-[#eab308] transition-colors flex items-center gap-2"
            >
              <i className="ri-add-line" />
              <span>Add Project</span>
            </button>
          </div>
        </div>

        {/* ===== Existing Project Cards (No Changes) ===== */}
           <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow ">
          <div className="relative h-48">
            <img
              alt="E-Commerce Platform"
              className="w-full h-full object-cover"
              src="https://readdy.ai/api/search-image?query=modern%20e-commerce%20website%20interface%20dark%20theme%20product%20showcase%20minimal%20design%20professional&width=400&height=300&seq=101&orientation=landscape"
            />
            <span className="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-700">
              Fullstack
            </span>
          </div>
          <div className="p-5 flex-1">
            <h3 className="font-bold text-black text-lg mb-2">
              E-Commerce Platform
            </h3>
            <p className="text-gray-500 text-sm line-clamp-2 mb-4">
              A full-featured e-commerce platform with shopping cart, payment
              integration, and admin dashboard.
            </p>
            <div className="flex items-center gap-4 mb-4">
              <a
                href="https://example.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-[#facc15] transition-colors"
                title="Live Demo"
              >
                <i className="ri-external-link-line text-xl" />
              </a>
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-black transition-colors"
                title="GitHub"
              >
                <i className="ri-github-line text-xl" />
              </a>
            </div>
            <div className="flex items-center gap-2">
              <button className="flex-1 bg-[#facc15] text-black py-2 rounded-lg font-medium hover:bg-[#eab308] transition-colors flex items-center justify-center gap-2">
                <i className="ri-edit-line" />
                <span>Edit</span>
              </button>
              <button className="px-4 py-2 border border-red-200 text-red-500 rounded-lg hover:bg-red-50 transition-colors">
                <i className="ri-delete-bin-line" />
              </button>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow ">
          <div className="relative h-48">
            <img
              alt="Portfolio Website"
              className="w-full h-full object-cover"
              src="https://readdy.ai/api/search-image?query=portfolio%20website%20design%20minimal%20yellow%20black%20theme%20creative%20professional%20web%20developer&width=400&height=300&seq=102&orientation=landscape"
            />
            <span className="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-700">
              React
            </span>
          </div>
          <div className="p-5 flex-1">
            <h3 className="font-bold text-black text-lg mb-2">
              Portfolio Website
            </h3>
            <p className="text-gray-500 text-sm line-clamp-2 mb-4">
              Personal portfolio website showcasing projects and skills with
              modern animations.
            </p>
            <div className="flex items-center gap-4 mb-4">
              <a
                href="https://example.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-[#facc15] transition-colors"
                title="Live Demo"
              >
                <i className="ri-external-link-line text-xl" />
              </a>
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-black transition-colors"
                title="GitHub"
              >
                <i className="ri-github-line text-xl" />
              </a>
            </div>
            <div className="flex items-center gap-2">
              <button className="flex-1 bg-[#facc15] text-black py-2 rounded-lg font-medium hover:bg-[#eab308] transition-colors flex items-center justify-center gap-2">
                <i className="ri-edit-line" />
                <span>Edit</span>
              </button>
              <button className="px-4 py-2 border border-red-200 text-red-500 rounded-lg hover:bg-red-50 transition-colors">
                <i className="ri-delete-bin-line" />
              </button>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow ">
          <div className="relative h-48">
            <img
              alt="Landing Page"
              className="w-full h-full object-cover"
              src="https://readdy.ai/api/search-image?query=modern%20landing%20page%20design%20clean%20minimal%20business%20website%20hero%20section%20professional&width=400&height=300&seq=103&orientation=landscape"
            />
            <span className="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-700">
              HTML
            </span>
          </div>
          <div className="p-5 flex-1">
            <h3 className="font-bold text-black text-lg mb-2">Landing Page</h3>
            <p className="text-gray-500 text-sm line-clamp-2 mb-4">
              Responsive landing page with smooth scrolling and modern CSS
              animations.
            </p>
            <div className="flex items-center gap-4 mb-4">
              <a
                href="https://example.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-[#facc15] transition-colors"
                title="Live Demo"
              >
                <i className="ri-external-link-line text-xl" />
              </a>
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-black transition-colors"
                title="GitHub"
              >
                <i className="ri-github-line text-xl" />
              </a>
            </div>
            <div className="flex items-center gap-2">
              <button className="flex-1 bg-[#facc15] text-black py-2 rounded-lg font-medium hover:bg-[#eab308] transition-colors flex items-center justify-center gap-2">
                <i className="ri-edit-line" />
                <span>Edit</span>
              </button>
              <button className="px-4 py-2 border border-red-200 text-red-500 rounded-lg hover:bg-red-50 transition-colors">
                <i className="ri-delete-bin-line" />
              </button>
            </div>
          </div>
        </div>
      </div>
      </div>

      {/* ================= MODAL ================= */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-black">
                  Add New Project
                </h2>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <i className="ri-close-line text-2xl"></i>
                </button>
              </div>
            </div>

            <form className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-black mb-2">
                    Project Title *
                  </label>
                  <input
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#facc15] focus:border-transparent"
                    placeholder="Enter project title"
                    required
                    type="text"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-black mb-2">
                    Project Image URL *
                  </label>
                  <input
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#facc15] focus:border-transparent"
                    placeholder="https://example.com/image.jpg"
                    required
                    type="url"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-black mb-2">
                    Description *
                  </label>
                  <textarea
                    rows="4"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#facc15] focus:border-transparent resize-none"
                    placeholder="Describe your project..."
                    required
                  ></textarea>
                </div>

                <div>
                  <label className="block text-sm font-medium text-black mb-2">
                    Category *
                  </label>
                  <select
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#facc15] focus:border-transparent"
                    required
                  >
                    <option value="React">React</option>
                    <option value="HTML">HTML</option>
                    <option value="Fullstack">Fullstack</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-black mb-2">
                    Live URL *
                  </label>
                  <input
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#facc15] focus:border-transparent"
                    placeholder="https://example.com"
                    required
                    type="url"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-black mb-2">
                    GitHub URL *
                  </label>
                  <input
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#facc15] focus:border-transparent"
                    placeholder="https://github.com/username/repo"
                    required
                    type="url"
                  />
                </div>

              </div>

              <div className="flex items-center justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="px-6 py-3 border border-gray-200 rounded-lg font-medium hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-6 py-3 bg-[#facc15] text-black rounded-lg font-semibold hover:bg-[#eab308] transition-colors"
                >
                  Add Project
                </button>
              </div>

            </form>
          </div>
        </div>
      )}
    </div>
  )
}

export default Projects